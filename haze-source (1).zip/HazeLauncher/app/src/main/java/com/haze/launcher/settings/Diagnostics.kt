package com.haze.launcher.settings

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.haze.launcher.CrashLog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class ExitRow(val title: String, val detail: String?)

@RequiresApi(30)
private fun reasonName(reason: Int): String = when (reason) {
    ApplicationExitInfo.REASON_ANR -> "Stopped responding (ANR)"
    ApplicationExitInfo.REASON_CRASH -> "Crash"
    ApplicationExitInfo.REASON_CRASH_NATIVE -> "Native crash"
    ApplicationExitInfo.REASON_DEPENDENCY_DIED -> "A needed service died"
    ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "Used too many resources"
    ApplicationExitInfo.REASON_EXIT_SELF -> "Closed itself"
    ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "Failed to start"
    ApplicationExitInfo.REASON_LOW_MEMORY -> "Killed by Android: low memory"
    ApplicationExitInfo.REASON_OTHER -> "Killed by Android (other reason)"
    ApplicationExitInfo.REASON_PERMISSION_CHANGE -> "Permission changed"
    ApplicationExitInfo.REASON_SIGNALED -> "Killed by a signal"
    ApplicationExitInfo.REASON_USER_REQUESTED -> "Force stopped from Settings"
    ApplicationExitInfo.REASON_USER_STOPPED -> "Stopped by the user"
    else -> "Other (code $reason)"
}

@RequiresApi(30)
private fun exits30(ctx: Context): List<ExitRow> {
    val am = ctx.getSystemService(ActivityManager::class.java) ?: return emptyList()
    val fmt = SimpleDateFormat("d MMM, h:mm a", Locale.getDefault())
    return try {
        am.getHistoricalProcessExitReasons(ctx.packageName, 0, 6).map {
            ExitRow(
                "${reasonName(it.reason)} · ${fmt.format(Date(it.timestamp))}",
                it.description?.takeIf { d -> d.isNotBlank() },
            )
        }
    } catch (e: Exception) {
        emptyList()
    }
}

private fun loadExits(ctx: Context): List<ExitRow> =
    if (Build.VERSION.SDK_INT >= 30) exits30(ctx) else emptyList()

/** Answers "why does Haze close?": Android's own exit history plus the last crash Haze caught. */
@Composable
fun DiagnosticsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var crash by remember { mutableStateOf(CrashLog.read(ctx)) }
    val exits = remember { loadExits(ctx) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp),
    ) {
        TopBar("Diagnostics", onBack)

        Section("Why did Haze close?") {
            if (exits.isEmpty()) {
                RowItem(
                    "Nothing recorded",
                    "Android 11 and newer keep a short history of why an app closed. If Haze closes again, come back here and it will be listed.",
                )
            } else {
                exits.forEach { RowItem(it.title, it.detail) }
            }
        }

        Section("Last crash report") {
            val text = crash
            if (text == null) {
                RowItem("No crash recorded", "If Haze crashes, the error is saved here so it can be fixed.")
            } else {
                RowItem("A crash was recorded", text.take(900))
                ActionRow("Copy full report") {
                    val cm = ctx.getSystemService(ClipboardManager::class.java)
                    cm?.setPrimaryClip(ClipData.newPlainText("Haze crash report", text))
                    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                }
                ActionRow("Clear report", Red) {
                    CrashLog.clear(ctx)
                    crash = null
                }
            }
        }
    }
}
