package com.haze.launcher.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haze.launcher.data.AppEntry

/** Long-press menu, iOS style: a small card with the app's quick actions. */
@Composable
fun AppMenu(
    app: AppEntry,
    inDock: Boolean,
    onDismiss: () -> Unit,
    onInfo: () -> Unit,
    onDock: () -> Unit,
    onHide: () -> Unit,
    onUninstall: () -> Unit,
) {
    val appear = remember(app.key) { Animatable(0f) }
    LaunchedEffect(app.key) {
        appear.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = 520f))
    }

    Box(Modifier.fillMaxSize()) {
        // Dim layer: tap anywhere outside the card to close
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0x99000000))
                .pointerInput(Unit) { detectTapGestures { onDismiss() } },
        )

        Column(
            Modifier
                .align(Alignment.Center)
                .width(270.dp)
                .graphicsLayer {
                    val s = 0.85f + 0.15f * appear.value
                    scaleX = s
                    scaleY = s
                    alpha = appear.value.coerceIn(0f, 1f)
                }
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xF22C2C2E))
                .pointerInput(Unit) { detectTapGestures { } },
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                RawIcon(app, 44.dp)
                Txt(app.label, 17.sp, Color.White, FontWeight.SemiBold, Modifier.weight(1f), maxLines = 2)
            }
            MenuRow("App info", Color.White, onInfo)
            MenuRow(if (inDock) "Remove from dock" else "Add to dock", Color.White, onDock)
            MenuRow("Hide app", Color.White, onHide)
            MenuRow("Uninstall", Color(0xFFFF453A), onUninstall)
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun MenuRow(text: String, color: Color, onClick: () -> Unit) {
    val latest by rememberUpdatedState(onClick)
    var pressed by remember { mutableStateOf(false) }
    Column {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x26FFFFFF)))
        Box(
            Modifier
                .fillMaxWidth()
                .height(50.dp)
                .background(if (pressed) Color(0x26FFFFFF) else Color.Transparent)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        },
                        onTap = { latest() },
                    )
                }
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            Txt(text, 17.sp, color)
        }
    }
}
