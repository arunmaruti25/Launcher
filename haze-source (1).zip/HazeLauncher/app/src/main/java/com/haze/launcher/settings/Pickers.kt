package com.haze.launcher.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haze.launcher.data.AppEntry
import com.haze.launcher.data.AppRepo
import com.haze.launcher.ui.RawIcon
import com.haze.launcher.ui.Txt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * A list of every installed app with a tick circle. Used for choosing dock apps and hidden apps.
 * [initial] turns the app list into the currently selected keys (read from saved settings),
 * [onChange] is called with the new list of selected keys.
 */
@Composable
fun AppPicker(
    title: String,
    hint: String,
    max: Int,
    initial: (List<AppEntry>) -> List<String>,
    onChange: (List<String>) -> Unit,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    val apps by produceState(emptyList<AppEntry>()) {
        value = withContext(Dispatchers.Default) { AppRepo.load(ctx) }
    }
    val keys = initial(apps)
    val latestKeys by rememberUpdatedState(keys)
    val latestChange by rememberUpdatedState(onChange)

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        TopBar(title, onBack)
        Txt(hint, 13.sp, SubText, modifier = Modifier.padding(bottom = 10.dp, start = 4.dp), maxLines = 3)
        LazyColumn(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(GroupBg),
        ) {
            items(apps, key = { it.key }) { app ->
                val on = app.key in keys
                Row(
                    Modifier
                        .fillMaxWidth()
                        .pointerInput(app.key) {
                            detectTapGestures {
                                val cur = latestKeys
                                if (app.key in cur) {
                                    latestChange(cur - app.key)
                                } else if (cur.size < max) {
                                    latestChange(cur + app.key)
                                }
                            }
                        }
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    RawIcon(app, 40.dp)
                    Txt(app.label, 16.sp, Color.White, modifier = Modifier.weight(1f))
                    Box(
                        Modifier
                            .size(24.dp)
                            .background(if (on) Accent else Color.Transparent, CircleShape)
                            .border(2.dp, if (on) Accent else SubText, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (on) Txt("✓", 14.sp, Color.White)
                    }
                }
            }
        }
    }
}
