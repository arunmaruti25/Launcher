package com.haze.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haze.launcher.data.AppEntry
import com.haze.launcher.data.Prefs
import kotlinx.coroutines.launch

/**
 * Swipe up on the home screen to open this: every app, grouped by letter, with search.
 * It only exists in composition while it is (partly) on screen.
 */
@Composable
fun AppDrawer(
    state: CcState,
    apps: List<AppEntry>,
    onOpen: (AppEntry) -> Unit,
    onMenu: (AppEntry) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val visible by remember(state) { derivedStateOf { state.progress > 0.002f } }
    if (!visible) return

    val focus = LocalFocusManager.current
    val cols = Prefs.get(LocalContext.current).gridCols.value
    var query by remember { mutableStateOf("") }

    val shown = remember(apps, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) apps else apps.filter { it.label.lowercase().contains(q) }
    }
    val groups = remember(shown) {
        shown.groupBy { a -> a.label.firstOrNull()?.takeIf { it.isLetter() }?.uppercaseChar()?.toString() ?: "#" }
    }
    val go = { a: AppEntry ->
        focus.clearFocus()
        onOpen(a)
    }

    Column(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                translationY = (1f - state.progress) * size.height
                alpha = (state.progress * 2f).coerceAtMost(1f)
            }
            .background(Color(0xF2000000))
            .pointerInput(Unit) { detectTapGestures { } } // stops taps reaching the home screen underneath
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp),
    ) {
        // Handle + search. Dragging this part down closes the drawer.
        Column(
            Modifier
                .fillMaxWidth()
                .pointerInput(state) {
                    detectVerticalDragGestures(
                        onDragEnd = { scope.launch { state.settle() } },
                        onDragCancel = { scope.launch { state.settle() } },
                    ) { _, dy -> state.drag(dy) }
                },
        ) {
            Box(
                Modifier
                    .padding(top = 10.dp, bottom = 12.dp)
                    .align(Alignment.CenterHorizontally)
                    .size(width = 38.dp, height = 5.dp)
                    .clip(CircleShape)
                    .background(Color(0x66FFFFFF)),
            )
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { shown.firstOrNull()?.let { go(it) } }),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x33FFFFFF))
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                    ) {
                        if (query.isEmpty()) Txt("Search apps", 17.sp, Color(0x99FFFFFF))
                        inner()
                    }
                },
            )
        }

        if (shown.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(top = 60.dp), contentAlignment = Alignment.TopCenter) {
                Txt("No apps found", 16.sp, Color(0x99FFFFFF))
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(cols),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
            ) {
                groups.forEach { (letter, list) ->
                    item(key = "h$letter", span = { GridItemSpan(maxLineSpan) }) {
                        Txt(
                            letter,
                            15.sp,
                            Color(0x99FFFFFF),
                            FontWeight.SemiBold,
                            Modifier.padding(start = 8.dp, top = 14.dp, bottom = 4.dp),
                        )
                    }
                    items(list, key = { it.key }) { app ->
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            AppIcon(app, go, onMenu, showLabel = true)
                        }
                    }
                }
            }
        }
    }
}
