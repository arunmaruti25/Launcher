package com.haze.launcher.aod

import android.service.dreams.DreamService

/**
 * Screen saver version of the clock. Android starts it by itself while the phone is
 * charging or docked (Settings > Display > Screen saver > Haze Clock).
 */
class HazeDream : DreamService() {
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isInteractive = false
        isFullscreen = true
        isScreenBright = false
        setContentView(AodView(this))
    }
}
