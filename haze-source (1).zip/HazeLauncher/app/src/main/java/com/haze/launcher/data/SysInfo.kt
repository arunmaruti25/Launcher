package com.haze.launcher.data

import android.app.ActivityManager
import android.content.Context
import android.os.Process

data class MemInfo(val hazeMb: Int, val usedPct: Int)

object SysInfo {
    /** Haze's own memory (PSS) and how full the phone's RAM is. Call off the main thread. */
    fun memory(ctx: Context): MemInfo {
        val am = ctx.getSystemService(ActivityManager::class.java) ?: return MemInfo(0, 0)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val usedPct = if (mi.totalMem > 0) (((mi.totalMem - mi.availMem) * 100) / mi.totalMem).toInt() else 0
        val mineKb = try {
            am.getProcessMemoryInfo(intArrayOf(Process.myPid())).firstOrNull()?.totalPss ?: 0
        } catch (e: Exception) {
            0
        }
        return MemInfo(mineKb / 1024, usedPct)
    }
}
