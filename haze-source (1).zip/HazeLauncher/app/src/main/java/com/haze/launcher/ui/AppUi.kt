package com.haze.launcher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haze.launcher.aod.NotifHub
import com.haze.launcher.data.AppEntry
import com.haze.launcher.data.IconCache
import com.haze.launcher.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** 0 = iOS squircle, 1 = circle, 2 = soft square. */
fun shapeFor(kind: Int): Shape = when (kind) {
    1 -> CircleShape
    2 -> RoundedCornerShape(percent = 10)
    else -> RoundedCornerShape(percent = 24)
}

/** Just the icon image, decoded off the main thread at its exact size. */
@Composable
fun RawIcon(app: AppEntry, size: Dp, shape: Shape = shapeFor(0), modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val px = remember(density, size) { with(density) { size.roundToPx() } }
    val bmp by produceState<ImageBitmap?>(IconCache.get(app.key, px), app.key, px) {
        if (value == null) value = withContext(Dispatchers.Default) { IconCache.load(ctx, app, px) }
    }
    Box(modifier.size(size).clip(shape)) {
        bmp?.let { Image(it, contentDescription = app.label, modifier = Modifier.size(size)) }
    }
}

/** An icon on the home screen / drawer: springy press, long-press menu, notification dot. */
@Composable
fun AppIcon(
    app: AppEntry,
    onOpen: (AppEntry) -> Unit,
    onMenu: (AppEntry) -> Unit,
    showLabel: Boolean,
) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val prefs = remember { Prefs.get(ctx) }
    val sizeDp = prefs.iconSize.value.dp
    val dot = prefs.badges.value && app.pkg in NotifHub.pkgs.value

    Column(
        modifier = Modifier.pressClick(
            onLongClick = {
                if (prefs.haptics.value) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onMenu(app)
            },
        ) { onOpen(app) },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box {
            RawIcon(app, sizeDp, shapeFor(prefs.iconShape.value))
            if (dot) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .offset(4.dp, (-4).dp)
                        .size(14.dp)
                        .background(Color(0xFFFF3B30), CircleShape),
                )
            }
        }
        if (showLabel && prefs.showLabels.value) {
            Txt(
                text = app.label,
                size = 11.sp,
                modifier = Modifier
                    .padding(top = 5.dp)
                    .widthIn(max = 76.dp),
                align = TextAlign.Center,
                shadow = true,
            )
        }
    }
}
