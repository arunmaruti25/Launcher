package com.haze.launcher.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.animation.core.snap
import androidx.compose.ui.platform.LocalContext
import com.haze.launcher.data.Prefs

/** Tiny text helper (we skip Material entirely to save RAM and APK size). */
@Composable
fun Txt(
    text: String,
    size: TextUnit,
    color: Color = Color.White,
    weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier,
    maxLines: Int = 1,
    align: TextAlign = TextAlign.Unspecified,
    shadow: Boolean = false,
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = TextStyle(
            color = color,
            fontSize = size,
            fontWeight = weight,
            textAlign = align,
            shadow = if (shadow) Shadow(Color(0x99000000), Offset(0f, 1f), 4f) else null,
        ),
        overflow = TextOverflow.Ellipsis,
        maxLines = maxLines,
    )
}

/**
 * iOS-style press feedback: a springy shrink while the finger is down.
 * The scale is read inside graphicsLayer, so animating it never triggers recomposition.
 */
fun Modifier.pressClick(onLongClick: (() -> Unit)? = null, onClick: () -> Unit): Modifier = composed {
    var pressed by remember { mutableStateOf(false) }
    val reduce = Prefs.get(LocalContext.current).reduceMotion.value
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.90f else 1f,
        animationSpec = if (reduce) snap<Float>() else spring<Float>(dampingRatio = 0.55f, stiffness = 600f),
        label = "press",
    )
    val click by rememberUpdatedState(onClick)
    val long by rememberUpdatedState(onLongClick)
    Modifier
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    pressed = true
                    tryAwaitRelease()
                    pressed = false
                },
                onLongPress = { long?.invoke() },
                onTap = { click() },
            )
        }
}

/** Frosted-glass style card (translucent, no blur: blur costs GPU time and RAM). */
@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Color(0x66000000))
            .padding(18.dp),
        content = content,
    )
}
