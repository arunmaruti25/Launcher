package com.haze.launcher.ui

import android.view.KeyEvent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haze.launcher.control.SystemControls
import com.haze.launcher.control.rememberTorch
import kotlinx.coroutines.launch

/** Open/close progress of the panel (0 = hidden, 1 = fully open). Driven by drag, then a spring. */
@Stable
class CcState(private val range: Float, private val sign: Float = 1f) {
    var progress by mutableFloatStateOf(0f)

    /** Set from the "reduce motion" setting: a short fade/slide instead of the springy one. */
    var fast = false
    private var lastDy = 0f

    // sign = 1 opens when dragged down (control center), -1 opens when dragged up (app drawer)
    fun drag(dy: Float) {
        lastDy = dy * sign
        progress = (progress + dy * sign / range).coerceIn(0f, 1f)
    }

    suspend fun settle() {
        val target = when {
            lastDy < -1f -> 0f
            lastDy > 1f -> 1f
            progress > 0.5f -> 1f
            else -> 0f
        }
        lastDy = 0f
        animateTo(target)
    }

    suspend fun animateTo(target: Float) {
        val spec = if (fast) tween<Float>(140) else spring<Float>(dampingRatio = 0.9f, stiffness = 400f)
        animate(progress, target, animationSpec = spec) { v, _ ->
            progress = v
        }
    }
}

/**
 * The panel is only composed while it is (even partly) visible, so it uses no memory when closed.
 * Its slide and fade are read inside graphicsLayer, so dragging never recomposes the tiles.
 */
@Composable
fun ControlCenterHost(cc: CcState) {
    val scope = rememberCoroutineScope()
    val visible by remember(cc) { derivedStateOf { cc.progress > 0.002f } }
    if (!visible) return

    Box(Modifier.fillMaxSize()) {
        // Dim layer: tap to close
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = cc.progress }
                .background(Color(0x80000000))
                .pointerInput(cc) { detectTapGestures { scope.launch { cc.animateTo(0f) } } },
        )

        Column(
            Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    translationY = -(1f - cc.progress) * size.height
                    alpha = (cc.progress * 2f).coerceAtMost(1f)
                }
                .pointerInput(cc) {
                    detectVerticalDragGestures(
                        onDragEnd = { scope.launch { cc.settle() } },
                        onDragCancel = { scope.launch { cc.settle() } },
                    ) { _, dy -> cc.drag(dy) }
                }
                .clip(RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp))
                .background(Color(0xF21C1C1E))
                .statusBarsPadding()
                .padding(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 12.dp),
        ) {
            ControlCenterContent(onLaunch = { cc.progress = 0f })
            Box(
                Modifier
                    .padding(top = 16.dp)
                    .align(Alignment.CenterHorizontally)
                    .size(width = 38.dp, height = 5.dp)
                    .clip(CircleShape)
                    .background(Color(0x66FFFFFF)),
            )
        }
    }
}

@Composable
private fun ControlCenterContent(onLaunch: () -> Unit) {
    val ctx = LocalContext.current
    val sys = remember { SystemControls(ctx) }
    val torch = rememberTorch(ctx)

    var rotationLocked by remember { mutableStateOf(!sys.autoRotate()) }
    var dnd by remember { mutableStateOf(sys.dndOn()) }

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val gap = 12.dp
        val cell = (maxWidth - gap * 3) / 4
        val wide = cell * 2 + gap
        val tile = Modifier.size(cell)

        Column(verticalArrangement = Arrangement.spacedBy(gap)) {
            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                ConnectivityCard(Modifier.size(wide), sys)
                MediaCard(Modifier.size(wide), sys)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                Column(Modifier.width(wide), verticalArrangement = Arrangement.spacedBy(gap)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        Tile(Glyph.ROTATE, rotationLocked, tile) {
                            sys.toggleRotate()?.let { autoOn -> rotationLocked = !autoOn }
                        }
                        Tile(Glyph.DND, dnd, tile) { dnd = sys.toggleDnd() }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        Tile(Glyph.BOLT, torch.on.value, tile) { torch.toggle() }
                        Tile(Glyph.CLOCK, false, tile) { onLaunch(); sys.openClockScreen() }
                    }
                }
                VSlider(remember { sys.brightness() }, Glyph.SUN, Modifier.size(cell, wide)) { sys.setBrightness(it) }
                VSlider(remember { sys.volume() }, Glyph.VOLUME, Modifier.size(cell, wide)) { sys.setVolume(it) }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                Tile(Glyph.CAMERA, false, tile) { onLaunch(); sys.camera() }
                Tile(Glyph.TIMER, false, tile) { onLaunch(); sys.clockApp() }
                Tile(Glyph.CALC, false, tile) { onLaunch(); sys.calculator() }
                Tile(Glyph.TUNE, false, tile) { onLaunch(); sys.hazeSettings() }
            }
        }
    }
}

@Composable
private fun Tile(glyph: Glyph, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg by animateColorAsState(
        targetValue = if (active) Color.White else Color(0x33FFFFFF),
        animationSpec = tween(180),
        label = "tile",
    )
    Box(
        modifier
            .pressClick(onClick = onClick)
            .clip(RoundedCornerShape(26.dp))
            .drawBehind { drawRect(bg) },
        contentAlignment = Alignment.Center,
    ) {
        GlyphIcon(glyph, if (active) Color(0xFF1C1C1E) else Color.White, Modifier.size(28.dp))
    }
}

@Composable
private fun RoundButton(glyph: Glyph, active: Boolean, activeColor: Color, onClick: () -> Unit) {
    val bg by animateColorAsState(
        targetValue = if (active) activeColor else Color(0x40FFFFFF),
        animationSpec = tween(180),
        label = "round",
    )
    Box(
        Modifier
            .size(56.dp)
            .pressClick(onClick = onClick)
            .clip(CircleShape)
            .drawBehind { drawRect(bg) },
        contentAlignment = Alignment.Center,
    ) {
        GlyphIcon(glyph, Color.White, Modifier.size(26.dp))
    }
}

@Composable
private fun ConnectivityCard(modifier: Modifier, sys: SystemControls) {
    val blue = Color(0xFF0A84FF)
    val orange = Color(0xFFFF9F0A)
    // The panel leaves composition when closed, so these are re-read every time it opens
    val wifi = remember { sys.wifiOn() }
    val bluetooth = remember { sys.bluetoothOn() }
    val airplane = remember { sys.airplaneOn() }

    Column(
        modifier
            .clip(RoundedCornerShape(30.dp))
            .background(Color(0x33FFFFFF)),
        verticalArrangement = Arrangement.SpaceEvenly,
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RoundButton(Glyph.AIRPLANE, airplane, orange) { sys.openAirplane() }
            RoundButton(Glyph.CELL, false, blue) { sys.openMobileData() }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RoundButton(Glyph.WIFI, wifi, blue) { sys.openInternet() }
            RoundButton(Glyph.BLUETOOTH, bluetooth, blue) { sys.openBluetooth() }
        }
    }
}

@Composable
private fun MediaCard(modifier: Modifier, sys: SystemControls) {
    var playing by remember { mutableStateOf(sys.musicActive()) }
    Column(
        modifier
            .clip(RoundedCornerShape(30.dp))
            .background(Color(0x33FFFFFF))
            .padding(16.dp),
    ) {
        Txt("Media", 13.sp, Color(0xB3FFFFFF), FontWeight.SemiBold)
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                MediaButton(Glyph.PREV, 26.dp) { sys.media(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
                MediaButton(if (playing) Glyph.PAUSE else Glyph.PLAY, 34.dp) {
                    sys.media(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                    playing = !playing
                }
                MediaButton(Glyph.NEXT, 26.dp) { sys.media(KeyEvent.KEYCODE_MEDIA_NEXT) }
            }
        }
    }
}

@Composable
private fun MediaButton(glyph: Glyph, iconSize: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    Box(
        Modifier
            .size(46.dp)
            .pressClick(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        GlyphIcon(glyph, Color.White, Modifier.size(iconSize))
    }
}

/** Tall pill slider like iOS: the white fill rises with your finger. Drawing reads the value in the draw phase only. */
@Composable
private fun VSlider(initial: Float, glyph: Glyph, modifier: Modifier, onChange: (Float) -> Unit) {
    var v by remember { mutableFloatStateOf(initial) }
    Box(
        modifier
            .clip(RoundedCornerShape(30.dp))
            .background(Color(0x33FFFFFF))
            .drawBehind {
                drawRect(
                    Color.White,
                    topLeft = Offset(0f, size.height * (1f - v)),
                    size = Size(size.width, size.height * v),
                )
            }
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    v = (1f - o.y / size.height).coerceIn(0f, 1f)
                    onChange(v)
                }
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, _ ->
                    change.consume()
                    v = (1f - change.position.y / size.height).coerceIn(0f, 1f)
                    onChange(v)
                }
            },
        contentAlignment = Alignment.BottomCenter,
    ) {
        GlyphIcon(glyph, Color(0xFF8E8E93), Modifier.padding(bottom = 18.dp).size(26.dp))
    }
}
