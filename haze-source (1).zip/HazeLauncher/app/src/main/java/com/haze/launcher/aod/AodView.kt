package com.haze.launcher.aod

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.haze.launcher.data.Prefs
import kotlin.random.Random

/**
 * The always-on style clock. Built from plain Views (not Compose) on purpose:
 * TextClock updates itself once a minute with no timers, and the whole screen is a few
 * hundred KB. Used by both the activity and the screen saver.
 *
 * Colours are dim greys on pure black, and the content drifts a few pixels every minute
 * so an AMOLED panel does not burn in.
 */
class AodView(context: Context) : FrameLayout(context) {

    private val dp = resources.displayMetrics.density
    private val prefs = Prefs.get(context)

    private val content = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
    }

    private val time = TextClock(context).apply {
        format12Hour = "h:mm"
        format24Hour = "HH:mm"
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 92f)
        setTextColor(0xFFC8C8C8.toInt())
        typeface = Typeface.create(if (prefs.aodBold.value) "sans-serif-medium" else "sans-serif-thin", Typeface.NORMAL)
        includeFontPadding = false
    }

    private val date = TextClock(context).apply {
        format12Hour = "EEE, d MMM"
        format24Hour = "EEE, d MMM"
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        setTextColor(0xFF8A8A8A.toInt())
    }

    private val icons = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
    }

    private val battery = TextView(context).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        setTextColor(0xFF6E6E6E.toInt())
    }

    private val batteryRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = showBattery(i)
    }

    private val drift = object : Runnable {
        override fun run() {
            val r = 22 * dp
            content.translationX = (Random.nextFloat() * 2f - 1f) * r
            content.translationY = (Random.nextFloat() * 2f - 1f) * r
            postDelayed(this, 60_000L)
        }
    }

    init {
        setBackgroundColor(Color.BLACK)
        content.addView(time)
        content.addView(date)
        content.addView(
            icons,
            LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, (22 * dp).toInt()).apply {
                topMargin = (26 * dp).toInt()
            },
        )
        content.addView(
            battery,
            LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply {
                topMargin = (14 * dp).toInt()
            },
        )
        addView(content, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ContextCompat.registerReceiver(
            context, batteryRx, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED,
        )?.let { showBattery(it) }
        battery.visibility = if (prefs.aodBattery.value) View.VISIBLE else View.GONE
        icons.visibility = if (prefs.aodIcons.value) View.VISIBLE else View.GONE
        NotifHub.listener = { refreshIcons() }
        refreshIcons()
        if (prefs.aodDrift.value) postDelayed(drift, 60_000L)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(drift)
        NotifHub.listener = null
        try { context.unregisterReceiver(batteryRx) } catch (e: Exception) { }
        super.onDetachedFromWindow()
    }

    private fun showBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        if (level < 0 || scale <= 0) return
        battery.text = "${level * 100 / scale}%" + if (charging) "  ·  charging" else ""
    }

    private fun refreshIcons() {
        icons.removeAllViews()
        val size = (20 * dp).toInt()
        val margin = (7 * dp).toInt()
        for (ic in NotifHub.icons.take(8)) {
            val d = runCatching { ic.loadDrawable(context) }.getOrNull() ?: continue
            d.mutate().setTint(0xFF9A9A9A.toInt())
            val iv = ImageView(context).apply { setImageDrawable(d) }
            icons.addView(
                iv,
                LinearLayout.LayoutParams(size, size).apply {
                    marginStart = margin
                    marginEnd = margin
                },
            )
        }
    }
}
