package com.haze.launcher.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** One saved setting. Reading it inside a composable makes the UI update when it changes. */
class Pref<T : Any>(private val sp: SharedPreferences, private val key: String, default: T) {

    private var state by mutableStateOf(read(default))

    var value: T
        get() = state
        set(v) {
            state = v
            write(v)
        }

    @Suppress("UNCHECKED_CAST")
    private fun read(d: T): T = when (d) {
        is Boolean -> sp.getBoolean(key, d) as T
        is Int -> sp.getInt(key, d) as T
        is String -> (sp.getString(key, d) ?: d) as T
        else -> d
    }

    private fun write(v: T) {
        val e = sp.edit()
        when (v) {
            is Boolean -> e.putBoolean(key, v)
            is Int -> e.putInt(key, v)
            is String -> e.putString(key, v)
            else -> Unit
        }
        e.apply()
    }
}

/** App keys are stored as "pkg/class|pkg/class". "!" means an explicitly empty list. */
fun keyList(s: String): List<String> =
    if (s == "!") emptyList() else s.split('|').filter { it.isNotBlank() }

fun joinKeys(l: List<String>): String = if (l.isEmpty()) "!" else l.joinToString("|")

/** All Haze settings in one place. Shared by the launcher, Settings and the clock screen. */
class Prefs private constructor(sp: SharedPreferences) {

    // Home screen
    val gridCols = Pref(sp, "gridCols", 4)
    val gridRows = Pref(sp, "gridRows", 6)
    val iconSize = Pref(sp, "iconSize", 56)
    val iconShape = Pref(sp, "iconShape", 0)          // 0 squircle, 1 circle, 2 square
    val showLabels = Pref(sp, "showLabels", true)
    val shade = Pref(sp, "shade", 40)                  // wallpaper dimming, 0..100
    val clockFormat = Pref(sp, "clockFormat", 0)       // 0 system, 1 12h, 2 24h
    val badges = Pref(sp, "badges", true)
    val dockApps = Pref(sp, "dockApps", "")            // "" = automatic
    val hiddenApps = Pref(sp, "hiddenApps", "")

    // Today page
    val todayPage = Pref(sp, "todayPage", true)
    val todayBattery = Pref(sp, "todayBattery", true)
    val todayAlarm = Pref(sp, "todayAlarm", true)
    val todayMemory = Pref(sp, "todayMemory", true)

    // Feel
    val swipeUp = Pref(sp, "swipeUp", true)
    val haptics = Pref(sp, "haptics", true)
    val reduceMotion = Pref(sp, "reduceMotion", false)

    // Clock screen
    val aodTimeout = Pref(sp, "aodTimeout", 10)        // minutes on battery, 0 = never
    val aodBrightness = Pref(sp, "aodBrightness", 4)   // percent
    val aodBattery = Pref(sp, "aodBattery", true)
    val aodIcons = Pref(sp, "aodIcons", true)
    val aodBold = Pref(sp, "aodBold", false)
    val aodDrift = Pref(sp, "aodDrift", true)

    companion object {
        @Volatile
        private var inst: Prefs? = null

        fun get(ctx: Context): Prefs = inst ?: synchronized(this) {
            inst ?: Prefs(
                ctx.applicationContext.getSharedPreferences("haze", Context.MODE_PRIVATE),
            ).also { inst = it }
        }
    }
}
