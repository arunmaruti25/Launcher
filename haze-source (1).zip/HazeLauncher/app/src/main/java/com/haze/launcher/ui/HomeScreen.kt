package com.haze.launcher.ui

import android.app.AlarmManager
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haze.launcher.aod.AodActivity
import com.haze.launcher.data.AppEntry
import com.haze.launcher.data.AppRepo
import com.haze.launcher.data.MemInfo
import com.haze.launcher.data.Prefs
import com.haze.launcher.data.SysInfo
import com.haze.launcher.data.joinKeys
import com.haze.launcher.data.keyList
import com.haze.launcher.settings.SettingsActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Home screen: [Today page] [app page 1] [app page 2] ... with a dock and page dots.
 *  - drag down from the very top edge: control center
 *  - swipe up anywhere else: app drawer with search
 *  - long-press an icon: menu (info, dock, hide, uninstall)
 *
 * Memory notes: the wallpaper is drawn by the system (we paint no background), only the visible
 * page is composed, and icons are decoded lazily into a small capped cache.
 *
 * [asHome] is true when Android started us as the home screen (Home button / swipe up), false
 * when we were opened as a preview from Settings. As the home screen we swallow the Back button,
 * because letting it finish the activity makes the home screen flash closed and restart.
 */
@Composable
fun HazeHome(homeSignal: Int, asHome: Boolean) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val prefs = remember { Prefs.get(ctx) }

    var version by remember { mutableIntStateOf(0) }
    PackageChangeEffect { version++ }

    val allApps by produceState(emptyList<AppEntry>(), version) {
        value = withContext(Dispatchers.Default) { AppRepo.load(ctx) }
    }
    val hiddenKeys = keyList(prefs.hiddenApps.value).toSet()
    val apps = remember(allApps, hiddenKeys) { allApps.filter { it.key !in hiddenKeys } }
    val dock = remember(allApps, prefs.dockApps.value) {
        AppRepo.resolveDock(ctx, allApps, prefs.dockApps.value)
    }
    val grid = remember(apps, dock) {
        val dockKeys = dock.map { it.key }.toSet()
        apps.filter { it.key !in dockKeys }
    }

    val cols = prefs.gridCols.value
    val rows = prefs.gridRows.value
    val perPage = cols * rows
    val todayOn = prefs.todayPage.value
    val appPages = maxOf(1, (grid.size + perPage - 1) / perPage)
    val homeIdx = if (todayOn) 1 else 0
    val totalPages = appPages + homeIdx
    val pager = rememberPagerState(initialPage = homeIdx) { totalPages }

    val screenH = ctx.resources.displayMetrics.heightPixels.toFloat()
    val cc = remember(density) { CcState(with(density) { 460.dp.toPx() }) }
    val drawer = remember(screenH) { CcState(screenH * 0.6f, -1f) }
    cc.fast = prefs.reduceMotion.value
    drawer.fast = prefs.reduceMotion.value
    val ccOpen by remember(cc) { derivedStateOf { cc.progress > 0.01f } }
    val drawerOpen by remember(drawer) { derivedStateOf { drawer.progress > 0.01f } }

    var menuApp by remember { mutableStateOf<AppEntry?>(null) }

    val open = remember { { a: AppEntry -> AppRepo.launch(ctx, a) } }
    val openFromDrawer = remember {
        { a: AppEntry ->
            AppRepo.launch(ctx, a)
            drawer.progress = 0f
        }
    }
    val showMenu = remember { { a: AppEntry -> menuApp = a } }
    val openAod = remember { { ctx.startActivity(Intent(ctx, AodActivity::class.java)) } }
    val openSettings = remember { { ctx.startActivity(Intent(ctx, SettingsActivity::class.java)) } }

    BackHandler(enabled = asHome || ccOpen || drawerOpen || menuApp != null || pager.currentPage != homeIdx) {
        scope.launch {
            when {
                menuApp != null -> menuApp = null
                drawerOpen -> drawer.animateTo(0f)
                ccOpen -> cc.animateTo(0f)
                pager.currentPage != homeIdx -> pager.animateScrollToPage(homeIdx)
                else -> Unit
            }
        }
    }
    // Pressing the Home button while already home: close everything, return to the main page
    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) {
            menuApp = null
            drawer.animateTo(0f)
            cc.animateTo(0f)
            pager.animateScrollToPage(homeIdx)
        }
    }

    val statusH = with(density) { WindowInsets.statusBars.getTop(this).toDp() }
    val swipeUpOn = prefs.swipeUp.value
    val shade = prefs.shade.value / 100f

    Box(Modifier.fillMaxSize()) {
        // Soft top/bottom shading so white text stays readable on any wallpaper
        Box(
            Modifier
                .fillMaxSize()
                .drawBehind {
                    drawRect(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = shade.coerceIn(0f, 1f)),
                                Color.Transparent,
                                Color.Transparent,
                                Color.Black.copy(alpha = (shade * 1.25f).coerceIn(0f, 1f)),
                            ),
                        ),
                    )
                },
        )

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .pointerInput(swipeUpOn) {
                    if (swipeUpOn) {
                        detectVerticalDragGestures(
                            onDragEnd = { scope.launch { drawer.settle() } },
                            onDragCancel = { scope.launch { drawer.settle() } },
                        ) { _, dy -> drawer.drag(dy) }
                    }
                },
        ) {
            HorizontalPager(
                state = pager,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            ) { page ->
                if (todayOn && page == 0) {
                    TodayPage(prefs, openAod, openSettings)
                } else {
                    val index = page - homeIdx
                    val slice = remember(grid, index, perPage) {
                        grid.drop(index * perPage).take(perPage)
                    }
                    AppPage(slice, cols, rows, open, showMenu)
                }
            }
            PageDots(pager)
            if (dock.isNotEmpty()) Dock(dock, prefs.iconSize.value, open, showMenu)
        }

        // Invisible strip along the top edge: drag down to open the control center
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(statusH + 14.dp)
                .pointerInput(cc) {
                    detectVerticalDragGestures(
                        onDragEnd = { scope.launch { cc.settle() } },
                        onDragCancel = { scope.launch { cc.settle() } },
                    ) { _, dy -> cc.drag(dy) }
                },
        )

        AppDrawer(drawer, apps, openFromDrawer, showMenu)
        ControlCenterHost(cc)

        menuApp?.let { app ->
            AppMenu(
                app = app,
                inDock = dock.any { it.key == app.key },
                onDismiss = { menuApp = null },
                onInfo = {
                    menuApp = null
                    AppRepo.showInfo(ctx, app)
                },
                onDock = {
                    val cur = dock.map { it.key }.toMutableList()
                    if (app.key in cur) {
                        cur.remove(app.key)
                    } else {
                        if (cur.size >= 4) cur.removeAt(cur.size - 1)
                        cur.add(app.key)
                    }
                    prefs.dockApps.value = joinKeys(cur)
                    menuApp = null
                },
                onHide = {
                    prefs.hiddenApps.value = joinKeys(keyList(prefs.hiddenApps.value) + app.key)
                    menuApp = null
                },
                onUninstall = {
                    menuApp = null
                    AppRepo.uninstall(ctx, app)
                },
            )
        }
    }
}

@Composable
private fun AppPage(
    apps: List<AppEntry>,
    cols: Int,
    rows: Int,
    onOpen: (AppEntry) -> Unit,
    onMenu: (AppEntry) -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(top = 20.dp, bottom = 4.dp),
    ) {
        for (r in 0 until rows) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .weight(1f),
            ) {
                for (c in 0 until cols) {
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center,
                    ) {
                        apps.getOrNull(r * cols + c)?.let { AppIcon(it, onOpen, onMenu, showLabel = true) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PageDots(pager: PagerState) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
    ) {
        repeat(pager.pageCount) { i ->
            Box(
                Modifier
                    .padding(horizontal = 3.5.dp)
                    .size(7.dp)
                    .background(if (i == pager.currentPage) Color.White else Color(0x66FFFFFF), CircleShape),
            )
        }
    }
}

@Composable
private fun Dock(apps: List<AppEntry>, iconDp: Int, onOpen: (AppEntry) -> Unit, onMenu: (AppEntry) -> Unit) {
    Row(
        Modifier
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .fillMaxWidth()
            .height((iconDp + 30).dp)
            .clip(RoundedCornerShape(34.dp))
            .background(Color(0x40FFFFFF)),
        horizontalArrangement = Arrangement.spacedBy(22.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        apps.take(4).forEach { AppIcon(it, onOpen, onMenu, showLabel = false) }
    }
}

@Composable
private fun TodayPage(prefs: Prefs, onOpenAod: () -> Unit, onOpenSettings: () -> Unit) {
    val ctx = LocalContext.current
    val now by rememberNow()
    val battery by rememberBattery()

    val is24 = when (prefs.clockFormat.value) {
        1 -> false
        2 -> true
        else -> android.text.format.DateFormat.is24HourFormat(ctx)
    }
    val time = remember(now, is24) {
        SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault()).format(Date(now))
    }
    val date = remember(now) {
        SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(now))
    }
    val alarmText = remember(now, is24) {
        ctx.getSystemService(AlarmManager::class.java)?.nextAlarmClock?.triggerTime?.let {
            SimpleDateFormat(if (is24) "EEE HH:mm" else "EEE h:mm a", Locale.getDefault()).format(Date(it))
        }
    }
    val wantMem = prefs.todayMemory.value
    val mem by produceState(MemInfo(0, 0), now / 60_000L, wantMem) {
        if (wantMem) value = withContext(Dispatchers.Default) { SysInfo.memory(ctx) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Column(Modifier.padding(start = 6.dp, bottom = 6.dp)) {
            Txt(date, 17.sp, Color(0xE6FFFFFF), FontWeight.Medium, shadow = true)
            Txt(time, 84.sp, Color.White, FontWeight.Thin, shadow = true)
        }

        if (prefs.todayBattery.value) {
            GlassCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Txt("Battery", 14.sp, Color(0xB3FFFFFF), FontWeight.SemiBold)
                        Txt(
                            "${battery.pct}%" + if (battery.charging) "  charging" else "",
                            14.sp,
                            Color.White,
                            FontWeight.SemiBold,
                        )
                    }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape)
                            .background(Color(0x33FFFFFF)),
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth((battery.pct / 100f).coerceIn(0.02f, 1f))
                                .fillMaxHeight()
                                .background(
                                    if (battery.pct <= 20 && !battery.charging) Color(0xFFFF453A) else Color(0xFF30D158),
                                    CircleShape,
                                ),
                        )
                    }
                }
            }
        }

        if (prefs.todayAlarm.value && alarmText != null) {
            GlassCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Txt("Next alarm", 14.sp, Color(0xB3FFFFFF), FontWeight.SemiBold)
                    Txt(alarmText, 14.sp, Color.White, FontWeight.SemiBold)
                }
            }
        }

        if (wantMem && mem.hazeMb > 0) {
            GlassCard {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Txt("Memory used by Haze", 14.sp, Color(0xB3FFFFFF), FontWeight.SemiBold)
                        Txt("${mem.hazeMb} MB", 14.sp, Color.White, FontWeight.SemiBold)
                    }
                    Txt("Phone RAM in use: ${mem.usedPct}%", 13.sp, Color(0x99FFFFFF))
                }
            }
        }

        GlassCard(Modifier.pressClick { onOpenAod() }) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Txt("Clock screen", 17.sp, Color.White, FontWeight.SemiBold)
                Txt("Always-on style black clock. Tap to start, double-tap to exit.", 13.sp, Color(0xB3FFFFFF), maxLines = 2)
            }
        }

        GlassCard(Modifier.pressClick { onOpenSettings() }) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Txt("Haze settings", 17.sp, Color.White, FontWeight.SemiBold)
                Txt("Layout, dock, hidden apps, clock screen, home app and more.", 13.sp, Color(0xB3FFFFFF), maxLines = 2)
            }
        }
    }
}
