package com.haze.launcher.aod

import android.graphics.drawable.Icon
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.compose.runtime.mutableStateOf

/** Hand-off between the notification listener, the clock screen and the home screen's icon dots. */
object NotifHub {
    @Volatile
    var icons: List<Icon> = emptyList()
        private set

    /** Packages that currently have a (non-ongoing) notification. Drives the dots on app icons. */
    val pkgs = mutableStateOf<Set<String>>(emptySet())

    @Volatile
    var listener: (() -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())

    fun update(list: List<Icon>, packages: Set<String>) {
        icons = list
        main.post {
            pkgs.value = packages
            listener?.invoke()
        }
    }
}

/** Only runs if the user grants Notification access. Keeps one small icon per app. */
class NotifService : NotificationListenerService() {

    override fun onListenerConnected() = refresh()
    override fun onNotificationPosted(sbn: StatusBarNotification) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification) = refresh()
    override fun onListenerDisconnected() = NotifHub.update(emptyList(), emptySet())

    private fun refresh() {
        val active: Array<StatusBarNotification> = try {
            activeNotifications ?: emptyArray()
        } catch (e: Exception) {
            emptyArray()
        }
        val seen = HashSet<String>()
        val out = ArrayList<Icon>()
        for (n in active) {
            if (n.isOngoing) continue
            if (seen.add(n.packageName)) n.notification.smallIcon?.let { out.add(it) }
        }
        NotifHub.update(out, seen.toSet())
    }
}
