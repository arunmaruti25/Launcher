package com.haze.launcher.settings

import android.app.NotificationManager
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.haze.launcher.MainActivity
import com.haze.launcher.aod.AodActivity
import com.haze.launcher.data.AppRepo
import com.haze.launcher.data.Prefs
import com.haze.launcher.data.joinKeys
import com.haze.launcher.data.keyList
import com.haze.launcher.ui.Txt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * What the "Haze" icon opens. Haze never grabs your home screen by itself: you choose here
 * whether Haze or your phone's own launcher is the home app, and you can change it any time.
 */
class SettingsActivity : ComponentActivity() {

    // Bumped on every resume so permission / default-launcher status refreshes after you come back
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val clear = android.graphics.Color.TRANSPARENT
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(clear),
            navigationBarStyle = SystemBarStyle.dark(clear),
        )
        setContent { SettingsRoot(resumeTick) }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}

private enum class Route { Main, Dock, Hidden, Diagnostics }

@Composable
private fun SettingsRoot(tick: Int) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs.get(ctx) }
    var route by remember { mutableStateOf(Route.Main) }
    BackHandler(enabled = route != Route.Main) { route = Route.Main }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        when (route) {
            Route.Main -> MainSettings(tick, prefs) { route = it }
            Route.Dock -> AppPicker(
                title = "Dock apps",
                hint = "Choose up to 4 apps for the dock at the bottom of the home screen.",
                max = 4,
                initial = { apps ->
                    val raw = prefs.dockApps.value
                    if (raw.isEmpty()) AppRepo.dock(ctx, apps).map { it.key } else keyList(raw)
                },
                onChange = { prefs.dockApps.value = joinKeys(it) },
                onBack = { route = Route.Main },
            )
            Route.Hidden -> AppPicker(
                title = "Hidden apps",
                hint = "Ticked apps are hidden from the home screen and app drawer. They stay installed.",
                max = Int.MAX_VALUE,
                initial = { keyList(prefs.hiddenApps.value) },
                onChange = { prefs.hiddenApps.value = joinKeys(it) },
                onBack = { route = Route.Main },
            )
            Route.Diagnostics -> DiagnosticsScreen { route = Route.Main }
        }
    }
}

@Composable
private fun MainSettings(tick: Int, prefs: Prefs, go: (Route) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(top = 12.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        Txt("Haze", 34.sp, Color.White, FontWeight.Bold)
        HomeAppSection(tick)
        PermissionsSection(tick)
        HomeScreenSection(prefs)
        AppsSection(prefs, go)
        TodaySection(prefs)
        FeelSection(prefs)
        ClockSection(prefs)
        AboutSection(tick, go)
    }
}

// ---- Home app (Haze launcher vs system launcher) ---------------------------------------------

private const val HOME_ALIAS = "com.haze.launcher.HomeAlias"

/** The app that currently answers the Home button: (package, label), or null if none is chosen. */
private fun currentHome(ctx: Context): Pair<String, String>? {
    val pm = ctx.packageManager
    val probe = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
    val ri = pm.resolveActivity(probe, PackageManager.MATCH_DEFAULT_ONLY) ?: return null
    val pkg = ri.activityInfo.packageName
    if (pkg == "android") return null // Android's "choose an app" dialog: no default picked
    return pkg to ri.loadLabel(pm).toString()
}

private fun setHomeAlias(ctx: Context, enabled: Boolean) {
    ctx.packageManager.setComponentEnabledSetting(
        ComponentName(ctx.packageName, HOME_ALIAS),
        if (enabled) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
        PackageManager.DONT_KILL_APP,
    )
}

private fun openHomeSettings(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (e: Exception) {
        }
    }
}

private fun open(ctx: Context, action: String, pkg: Boolean = false) {
    try {
        val i = Intent(action)
        if (pkg) i.data = Uri.parse("package:${ctx.packageName}")
        ctx.startActivity(i)
    } catch (e: Exception) {
    }
}

@Composable
private fun HomeAppSection(tick: Int) {
    val ctx = LocalContext.current
    var bump by remember { mutableIntStateOf(0) }
    val current = remember(tick, bump) { currentHome(ctx) }
    val isHaze = current?.first == ctx.packageName
    // After the system "Set as default home app?" dialog closes we just re-check the status
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { bump++ }

    fun useHaze() {
        setHomeAlias(ctx, true)
        bump++
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = ctx.getSystemService(RoleManager::class.java)
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                if (!rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                }
                return
            }
        }
        openHomeSettings(ctx)
    }

    Section("Home app") {
        RowItem(
            title = if (isHaze) "Haze is your home screen" else "Haze is not your home screen",
            subtitle = when {
                isHaze -> "Pressing Home, or swiping up from an app, shows Haze."
                current != null -> "Your home screen is currently: ${current.second}"
                else -> "No default home app is chosen yet."
            },
        )
        if (!isHaze) {
            ActionRow("Use Haze as my home screen") { useHaze() }
        } else {
            ActionRow("Go back to my phone's launcher", Red) {
                setHomeAlias(ctx, false)
                bump++
                openHomeSettings(ctx)
            }
        }
        ActionRow("Choose a different home app…") { openHomeSettings(ctx) }
        ActionRow("Preview Haze home screen") {
            ctx.startActivity(Intent(ctx, MainActivity::class.java))
        }
        RowItem(
            title = "About swipe-up from an app",
            subtitle = "That gesture is drawn by Android's own launcher, and some phones switch it off or change it when another home app is chosen. If it misbehaves, use 3-button navigation (Settings > System > Navigation) or go back to your phone's launcher above.",
        )
    }
}

// ---- Permissions ---------------------------------------------------------------------------

@Composable
private fun PermissionsSection(tick: Int) {
    val ctx = LocalContext.current
    val canWrite = remember(tick) { Settings.System.canWrite(ctx) }
    val dnd = remember(tick) {
        ctx.getSystemService(NotificationManager::class.java)?.isNotificationPolicyAccessGranted == true
    }
    val notif = remember(tick) { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }

    Section("Permissions") {
        StatusRow("Brightness and rotation", "Control center sliders and the rotation tile", canWrite) {
            open(ctx, Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg = true)
        }
        StatusRow("Do Not Disturb", "Control center focus tile", dnd) {
            open(ctx, Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
        }
        StatusRow("Notification access", "Dots on app icons and icons on the clock screen", notif) {
            open(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        }
    }
}

// ---- Home screen ---------------------------------------------------------------------------

@Composable
private fun HomeScreenSection(prefs: Prefs) {
    val sizes = listOf(50, 56, 62)
    Section("Home screen") {
        ChoiceRow("Columns", listOf("4", "5"), (prefs.gridCols.value - 4).coerceIn(0, 1)) {
            prefs.gridCols.value = 4 + it
        }
        ChoiceRow("Rows", listOf("5", "6", "7"), (prefs.gridRows.value - 5).coerceIn(0, 2)) {
            prefs.gridRows.value = 5 + it
        }
        ChoiceRow(
            "Icon size",
            listOf("Small", "Medium", "Large"),
            sizes.indexOf(prefs.iconSize.value).coerceAtLeast(1),
        ) { prefs.iconSize.value = sizes[it] }
        ChoiceRow("Icon shape", listOf("Squircle", "Circle", "Square"), prefs.iconShape.value.coerceIn(0, 2)) {
            prefs.iconShape.value = it
        }
        ToggleRow("App names", checked = prefs.showLabels.value) { prefs.showLabels.value = it }
        SliderRow("Wallpaper dimming", prefs.shade.value, "${prefs.shade.value}%") { prefs.shade.value = it }
        ChoiceRow("Clock format", listOf("System", "12-hour", "24-hour"), prefs.clockFormat.value.coerceIn(0, 2)) {
            prefs.clockFormat.value = it
        }
    }
}

@Composable
private fun AppsSection(prefs: Prefs, go: (Route) -> Unit) {
    val hidden = keyList(prefs.hiddenApps.value).size
    val dockRaw = prefs.dockApps.value
    Section("Apps") {
        RowItem(
            "Dock apps",
            if (dockRaw.isEmpty()) "Automatic: phone, messages, browser, camera" else "${keyList(dockRaw).size} chosen",
            onClick = { go(Route.Dock) },
        ) { Txt("›", 22.sp, SubText) }
        RowItem(
            "Hidden apps",
            if (hidden == 0) "None" else "$hidden hidden",
            onClick = { go(Route.Hidden) },
        ) { Txt("›", 22.sp, SubText) }
        ToggleRow(
            "Notification dots",
            "Show a red dot on apps with a notification (needs notification access)",
            prefs.badges.value,
        ) { prefs.badges.value = it }
    }
}

@Composable
private fun TodaySection(prefs: Prefs) {
    Section("Today page") {
        ToggleRow("Show Today page", "The page to the left of your apps", prefs.todayPage.value) {
            prefs.todayPage.value = it
        }
        ToggleRow("Battery card", checked = prefs.todayBattery.value) { prefs.todayBattery.value = it }
        ToggleRow("Next alarm card", checked = prefs.todayAlarm.value) { prefs.todayAlarm.value = it }
        ToggleRow("Memory card", "Shows how much RAM Haze is using", prefs.todayMemory.value) {
            prefs.todayMemory.value = it
        }
    }
}

@Composable
private fun FeelSection(prefs: Prefs) {
    Section("Gestures and feel") {
        ToggleRow("Swipe up for app drawer", "Swipe up on the home screen to search and browse all apps", prefs.swipeUp.value) {
            prefs.swipeUp.value = it
        }
        ToggleRow("Haptic feedback", "A small buzz on long-press", prefs.haptics.value) { prefs.haptics.value = it }
        ToggleRow("Reduce motion", "Simpler animations, slightly lighter on the battery", prefs.reduceMotion.value) {
            prefs.reduceMotion.value = it
        }
    }
}

// ---- Clock screen --------------------------------------------------------------------------

@Composable
private fun ClockSection(prefs: Prefs) {
    val ctx = LocalContext.current
    val timeouts = listOf(0, 5, 10, 30)
    val levels = listOf(2, 4, 10, 25)
    Section("Clock screen") {
        ActionRow("Start clock screen now") { ctx.startActivity(Intent(ctx, AodActivity::class.java)) }
        ActionRow("Use as screen saver while charging") { open(ctx, Settings.ACTION_DREAM_SETTINGS) }
        ChoiceRow(
            "Auto-off on battery",
            listOf("Never", "5 min", "10 min", "30 min"),
            timeouts.indexOf(prefs.aodTimeout.value).coerceAtLeast(0),
        ) { prefs.aodTimeout.value = timeouts[it] }
        ChoiceRow(
            "Brightness",
            listOf("2%", "4%", "10%", "25%"),
            levels.indexOf(prefs.aodBrightness.value).coerceAtLeast(1),
        ) { prefs.aodBrightness.value = levels[it] }
        ToggleRow("Battery level", checked = prefs.aodBattery.value) { prefs.aodBattery.value = it }
        ToggleRow("Notification icons", checked = prefs.aodIcons.value) { prefs.aodIcons.value = it }
        ToggleRow("Bolder digits", checked = prefs.aodBold.value) { prefs.aodBold.value = it }
        ToggleRow("Drift slowly", "Moves the clock a little every minute to protect AMOLED screens", prefs.aodDrift.value) {
            prefs.aodDrift.value = it
        }
    }
}

// ---- About / diagnostics -------------------------------------------------------------------

@Composable
private fun AboutSection(tick: Int, go: (Route) -> Unit) {
    val ctx = LocalContext.current
    val mem by produceState(0, tick) {
        value = withContext(Dispatchers.Default) {
            try {
                val am = ctx.getSystemService(android.app.ActivityManager::class.java)
                (am?.getProcessMemoryInfo(intArrayOf(Process.myPid()))?.firstOrNull()?.totalPss ?: 0) / 1024
            } catch (e: Exception) {
                0
            }
        }
    }
    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    Section("About") {
        RowItem("Memory used by Haze", if (mem > 0) "$mem MB right now" else "Measuring…")
        RowItem(
            "Diagnostics",
            "Why Haze closed and the last crash report",
            onClick = { go(Route.Diagnostics) },
        ) { Txt("›", 22.sp, SubText) }
        RowItem("Version", version)
    }
}
