package com.haze.launcher

import android.content.ComponentCallbacks2
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.haze.launcher.data.IconCache
import com.haze.launcher.ui.HazeHome

class MainActivity : ComponentActivity() {

    // Bumped every time the Home button is pressed while we are already on screen
    private var homeSignal by mutableIntStateOf(0)

    // True when Android started us as the home screen; false for a preview opened from Settings
    private var asHome by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        asHome = intent.hasCategory(Intent.CATEGORY_HOME)
        val clear = android.graphics.Color.TRANSPARENT
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(clear),
            navigationBarStyle = SystemBarStyle.dark(clear),
        )
        setContent { HazeHome(homeSignal, asHome) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        asHome = intent.hasCategory(Intent.CATEGORY_HOME)
        if (asHome) homeSignal++
    }

    // When another app is on top we give the icon memory back; icons reload in a few ms.
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) IconCache.clear()
    }
}
