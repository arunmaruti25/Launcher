package com.haze.launcher.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat

data class BatteryInfo(val pct: Int, val charging: Boolean)

/** Current time, refreshed only once a minute by the system's TIME_TICK broadcast (no timers, no polling). */
@Composable
fun rememberNow(): State<Long> {
    val ctx = LocalContext.current
    val now = remember { mutableLongStateOf(System.currentTimeMillis()) }
    DisposableEffect(ctx) {
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { now.longValue = System.currentTimeMillis() }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        ContextCompat.registerReceiver(ctx, rx, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        now.longValue = System.currentTimeMillis()
        onDispose { ctx.unregisterReceiver(rx) }
    }
    return now
}

@Composable
fun rememberBattery(): State<BatteryInfo> {
    val ctx = LocalContext.current
    val state = remember { mutableStateOf(BatteryInfo(0, false)) }
    DisposableEffect(ctx) {
        fun parse(i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            if (level >= 0 && scale > 0) state.value = BatteryInfo(level * 100 / scale, charging)
        }
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) = parse(i)
        }
        val sticky = ContextCompat.registerReceiver(
            ctx, rx, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        sticky?.let { parse(it) }
        onDispose { ctx.unregisterReceiver(rx) }
    }
    return state
}

/** Calls [onChange] when an app is installed, updated or removed. */
@Composable
fun PackageChangeEffect(onChange: () -> Unit) {
    val ctx = LocalContext.current
    val latest = rememberUpdatedState(onChange)
    DisposableEffect(ctx) {
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { latest.value() }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, rx, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { ctx.unregisterReceiver(rx) }
    }
}
