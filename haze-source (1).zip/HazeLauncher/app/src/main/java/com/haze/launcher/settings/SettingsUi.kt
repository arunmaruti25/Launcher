package com.haze.launcher.settings

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haze.launcher.ui.Txt
import kotlin.math.roundToInt

// iOS dark-mode palette
internal val GroupBg = Color(0xFF1C1C1E)
internal val GroupPressed = Color(0xFF2C2C2E)
internal val Separator = Color(0xFF38383A)
internal val SubText = Color(0xFF8E8E93)
internal val Accent = Color(0xFF0A84FF)
internal val Green = Color(0xFF30D158)
internal val Red = Color(0xFFFF453A)

/** A rounded group of rows. The 1dp gaps between rows show the separator colour behind them. */
@Composable
fun Section(title: String?, content: @Composable ColumnScope.() -> Unit) {
    Column {
        if (title != null) {
            Txt(
                title.uppercase(),
                13.sp,
                SubText,
                FontWeight.Medium,
                Modifier.padding(start = 16.dp, bottom = 7.dp),
            )
        }
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Separator),
            verticalArrangement = Arrangement.spacedBy(1.dp),
            content = content,
        )
    }
}

@Composable
private fun RowBase(onClick: (() -> Unit)?, content: @Composable RowScope.() -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val latest by rememberUpdatedState(onClick)
    val tap = if (onClick != null) {
        Modifier.pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    pressed = true
                    tryAwaitRelease()
                    pressed = false
                },
                onTap = { latest?.invoke() },
            )
        }
    } else {
        Modifier
    }
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (pressed) GroupPressed else GroupBg)
            .then(tap)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

@Composable
fun RowItem(
    title: String,
    subtitle: String? = null,
    titleColor: Color = Color.White,
    onClick: (() -> Unit)? = null,
    trailing: @Composable (() -> Unit)? = null,
) {
    RowBase(onClick) {
        Column(Modifier.weight(1f)) {
            Txt(title, 16.sp, titleColor, maxLines = 2)
            if (subtitle != null) {
                Txt(subtitle, 13.sp, SubText, modifier = Modifier.padding(top = 2.dp), maxLines = 6)
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(12.dp))
            trailing()
        }
    }
}

@Composable
fun ActionRow(title: String, color: Color = Accent, subtitle: String? = null, onClick: () -> Unit) {
    RowItem(title, subtitle, titleColor = color, onClick = onClick)
}

@Composable
fun StatusRow(title: String, subtitle: String, ok: Boolean, onClick: () -> Unit) {
    RowItem(title, subtitle, onClick = onClick) {
        Txt(if (ok) "On" else "Set up", 15.sp, if (ok) Green else Accent, FontWeight.SemiBold)
    }
}

@Composable
fun ToggleRow(title: String, subtitle: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    RowItem(title, subtitle, onClick = { onChange(!checked) }) {
        HazeSwitch(checked)
    }
}

@Composable
private fun HazeSwitch(checked: Boolean) {
    val t by animateFloatAsState(if (checked) 1f else 0f, tween(160), label = "switch")
    Box(
        Modifier
            .size(width = 51.dp, height = 31.dp)
            .clip(CircleShape)
            .drawBehind { drawRect(lerp(Color(0xFF39393D), Green, t)) },
    ) {
        Box(
            Modifier
                .offset { IntOffset((t * 20.dp.toPx()).roundToInt() + 2.dp.roundToPx(), 2.dp.roundToPx()) }
                .size(27.dp)
                .background(Color.White, CircleShape),
        )
    }
}

/** Segmented control, like iOS: one row of choices, the selected one highlighted. */
@Composable
fun ChoiceRow(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val latest by rememberUpdatedState(onSelect)
    RowBase(null) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Txt(title, 16.sp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(9.dp))
                    .background(GroupPressed)
                    .padding(2.dp),
            ) {
                options.forEachIndexed { i, label ->
                    Box(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(7.dp))
                            .background(if (i == selected) Color(0xFF636366) else Color.Transparent)
                            .pointerInput(i) { detectTapGestures { latest(i) } }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Txt(label, 14.sp, Color.White, if (i == selected) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
            }
        }
    }
}

private fun snap(fraction: Float): Int = (fraction.coerceIn(0f, 1f) * 20).roundToInt() * 5

/** 0..100 slider in steps of 5. */
@Composable
fun SliderRow(title: String, value: Int, label: String, onChange: (Int) -> Unit) {
    val latest by rememberUpdatedState(onChange)
    RowBase(null) {
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Txt(title, 16.sp)
                Txt(label, 15.sp, SubText)
            }
            Box(
                Modifier
                    .padding(top = 10.dp)
                    .fillMaxWidth()
                    .height(30.dp)
                    .pointerInput(Unit) {
                        detectTapGestures { o -> latest(snap(o.x / size.width)) }
                    }
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures { change, _ ->
                            change.consume()
                            latest(snap(change.position.x / size.width))
                        }
                    }
                    .drawBehind {
                        val track = 6.dp.toPx()
                        val r = 12.dp.toPx()
                        val y = (size.height - track) / 2f
                        val fillW = size.width * value / 100f
                        drawRoundRect(Color(0xFF3A3A3C), Offset(0f, y), Size(size.width, track), CornerRadius(track / 2f))
                        drawRoundRect(Accent, Offset(0f, y), Size(fillW, track), CornerRadius(track / 2f))
                        drawCircle(Color.White, r, Offset(fillW.coerceIn(r, size.width - r), size.height / 2f))
                    },
            )
        }
    }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .pointerInput(onBack) { detectTapGestures { onBack() } }
                .padding(end = 16.dp, top = 8.dp, bottom = 8.dp),
        ) {
            Txt("‹ Back", 17.sp, Accent)
        }
        Txt(title, 20.sp, Color.White, FontWeight.SemiBold)
    }
}
