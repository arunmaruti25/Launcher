plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.haze.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.haze.launcher"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }

    // One fixed key for every build, so a new APK installs over the old one and keeps your settings.
    // (The key lives in the repo on purpose: it only signs this personal app.)
    signingConfigs {
        create("haze") {
            storeFile = file("haze.keystore")
            storePassword = "haze1234"
            keyAlias = "haze"
            keyPassword = "haze1234"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("haze")
        }
        release {
            // Small, fast APK: code + resource shrinking
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("haze")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { compose = true }

    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    // Deliberately tiny dependency list: no Material, no icon packs, no image loaders
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    // Installs the pre-compiled startup profiles that ship inside Compose: faster start, less jank
    implementation("androidx.profileinstaller:profileinstaller:1.4.1")
}
