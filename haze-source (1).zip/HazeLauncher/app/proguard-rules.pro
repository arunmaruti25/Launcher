# Services and activities are referenced from the manifest and kept automatically.
# Nothing else needs special rules.
