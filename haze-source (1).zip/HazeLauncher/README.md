# Haze Launcher 1.1

iOS-style home screen, app drawer, control center, settings and always-on clock for Android. Kotlin + Jetpack Compose, no Material library, no image loader, no third-party dependencies.

## Build the APK without Android Studio (GitHub)
1. Create a GitHub repository and upload `haze-source.zip` (do not unzip it).
2. Add the workflow file at `.github/workflows/build-apk.yml` (see the one in this project; the zip-based version unpacks `haze-source.zip` first).
3. Open the repo's **Actions** tab. The "Build APK" workflow starts on its own (or press **Run workflow**).
4. When it finishes (about 5 minutes), open the run and download **haze-launcher-apk** at the bottom, unzip it and install the `.apk`.

## Build the APK with Android Studio
Open the `HazeLauncher` folder in Android Studio (Ladybug or newer), let Gradle sync, then `Build > Build Bundle(s) / APK(s) > Build APK(s)` with the **release** variant.

## Updating from version 1.0
Version 1.1 is signed with a fixed key (`app/haze.keystore`). Builds from now on install over each other and keep your settings. **Uninstall the old 1.0 build once** before installing 1.1, because 1.0 was signed with a random key.

## How it works now
- The **Haze** icon opens **Settings**. Haze no longer takes over your phone by itself.
- Settings > **Home app**: "Use Haze as my home screen" turns Haze on as a home app and shows Android's one-tap confirmation. "Go back to my phone's launcher" turns it off again. You can switch any time.
- **Preview Haze home screen** opens the home screen as a normal app, to try it without changing anything.

## Using it
- Swipe right from the first app page for the Today page (time, battery, next alarm, memory, shortcuts).
- **Swipe up** on the home screen for the app drawer (all apps by letter, with search).
- Drag down from the very top edge for the control center. Drag it up or tap outside to close.
- **Long-press** an icon for: App info, Add/Remove from dock, Hide app, Uninstall.
- Red dots on icons show apps with notifications (needs notification access).
- Clock screen: double-tap to exit. It closes itself after the time you choose when on battery.

## Settings
Home app switch, permissions checklist, columns/rows, icon size and shape, app names, wallpaper dimming, 12/24-hour, dock apps, hidden apps, Today page cards, swipe-up drawer, haptics, reduce motion, clock screen (auto-off, brightness, battery, icons, bold digits, drift), memory used by Haze, and Diagnostics.

## If Haze closes unexpectedly
Open Haze > Settings > About > **Diagnostics**. It lists why Android last closed Haze (crash, low memory, force stop...) and shows the last crash report with a Copy button.

## Why it is light on RAM
- No wallpaper bitmap: the system draws the wallpaper behind the launcher.
- Only the visible app page is composed. Icons are decoded off-thread at exact size into a 6 MB capped cache that is cleared when another app is in front.
- The control center and app drawer are not in memory while closed.
- Time comes from the system's once-a-minute tick, so there are no timers or polling loops.
- The clock screen uses plain Views and `TextClock`.
- Release builds are minified, resource-shrunk and ship with startup profiles.
- The Today page shows how much memory Haze is actually using.

## Limits (Android rules, no root)
- Wi-Fi, Bluetooth, mobile data and airplane mode buttons open the system panel or settings page. Apps cannot flip them directly.
- The swipe-up-from-an-app animation belongs to Android's own launcher. Some phones change or disable it when another home app is chosen.
- This is a screen-on clock, not the hardware AOD. On LCD the backlight stays lit, so it closes itself after the chosen time on battery. Best use on LCD: bedside clock while charging, via the screen saver.
- The real system notification shade and Quick Settings still exist. This control center is a separate panel inside the launcher.
