package com.haze.launcher.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.haze.launcher.aod.AodActivity
import com.haze.launcher.data.AppEntry
import com.haze.launcher.data.AppRepo
import com.haze.launcher.data.IconCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val COLS = 4
private const val ROWS = 6
private const val PER_PAGE = COLS * ROWS

/**
 * Home screen: [Today page] [app page 1] [app page 2] ... with a dock and page dots.
 * Swipe down from the very top edge to pull the control center.
 *
 * Memory notes: the wallpaper is drawn by the system (we paint no background), only the visible
 * page is composed, and icons are decoded lazily into a small capped cache.
 */
@Composable
fun HazeHome(homeSignal: Int) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    var version by remember { mutableIntStateOf(0) }
    PackageChangeEffect { version++ }

    val apps by produceState(emptyList<AppEntry>(), version) {
        value = withContext(Dispatchers.Default) { AppRepo.load(ctx) }
    }
    val dock = remember(apps) { AppRepo.dock(ctx, apps) }
    val grid = remember(apps, dock) { apps.filter { a -> dock.none { it.key == a.key } } }

    val pageCount = maxOf(1, (grid.size + PER_PAGE - 1) / PER_PAGE)
    val pager = rememberPagerState(initialPage = 1) { pageCount + 1 }

    val cc = remember(density) { CcState(with(density) { 460.dp.toPx() }) }
    val ccOpen by remember(cc) { derivedStateOf { cc.progress > 0.01f } }

    val open = remember { { a: AppEntry -> AppRepo.launch(ctx, a) } }
    val info = remember { { a: AppEntry -> AppRepo.showInfo(ctx, a) } }
    val openAod = remember { { ctx.startActivity(Intent(ctx, AodActivity::class.java)) } }

    BackHandler(enabled = ccOpen || pager.currentPage != 1) {
        scope.launch {
            if (ccOpen) cc.animateTo(0f) else pager.animateScrollToPage(1)
        }
    }
    // Pressing the Home button while already home: close panel, return to the main page
    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) {
            cc.animateTo(0f)
            pager.animateScrollToPage(1)
        }
    }

    val statusH = with(density) { WindowInsets.statusBars.getTop(this).toDp() }

    Box(Modifier.fillMaxSize()) {
        // Soft top/bottom shading so white text stays readable on any wallpaper
        Box(
            Modifier
                .fillMaxSize()
                .drawBehind {
                    drawRect(
                        Brush.verticalGradient(
                            listOf(Color(0x66000000), Color.Transparent, Color.Transparent, Color(0x80000000)),
                        ),
                    )
                },
        )

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
        ) {
            HorizontalPager(
                state = pager,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            ) { page ->
                if (page == 0) {
                    TodayPage(openAod)
                } else {
                    val slice = remember(grid, page) {
                        grid.drop((page - 1) * PER_PAGE).take(PER_PAGE)
                    }
                    AppPage(slice, open, info)
                }
            }
            PageDots(pager)
            Dock(dock, open, info)
        }

        // Invisible strip along the top edge: drag down to open the control center
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(statusH + 14.dp)
                .pointerInput(cc) {
                    detectVerticalDragGestures(
                        onDragEnd = { scope.launch { cc.settle() } },
                        onDragCancel = { scope.launch { cc.settle() } },
                    ) { _, dy -> cc.drag(dy) }
                },
        )

        ControlCenterHost(cc)
    }
}

@Composable
private fun AppPage(apps: List<AppEntry>, onOpen: (AppEntry) -> Unit, onInfo: (AppEntry) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(top = 20.dp, bottom = 4.dp),
    ) {
        for (r in 0 until ROWS) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .weight(1f),
            ) {
                for (c in 0 until COLS) {
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center,
                    ) {
                        apps.getOrNull(r * COLS + c)?.let { AppIcon(it, onOpen, onInfo, showLabel = true) }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppIcon(
    app: AppEntry,
    onOpen: (AppEntry) -> Unit,
    onInfo: (AppEntry) -> Unit,
    showLabel: Boolean,
) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val px = remember(density) { with(density) { 56.dp.roundToPx() } }

    // Decoded off the main thread, only for icons that are actually on screen
    val bmp by produceState<ImageBitmap?>(IconCache.get(app.key, px), app.key, px) {
        if (value == null) value = withContext(Dispatchers.Default) { IconCache.load(ctx, app, px) }
    }

    Column(
        modifier = Modifier.pressClick(
            onLongClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onInfo(app)
            },
        ) { onOpen(app) },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(percent = 24)),
        ) {
            bmp?.let { Image(it, contentDescription = app.label, modifier = Modifier.fillMaxSize()) }
        }
        if (showLabel) {
            Txt(
                text = app.label,
                size = 11.sp,
                modifier = Modifier
                    .padding(top = 5.dp)
                    .widthIn(max = 72.dp),
                shadow = true,
            )
        }
    }
}

@Composable
private fun PageDots(pager: PagerState) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
    ) {
        repeat(pager.pageCount) { i ->
            Box(
                Modifier
                    .padding(horizontal = 3.5.dp)
                    .size(7.dp)
                    .background(if (i == pager.currentPage) Color.White else Color(0x66FFFFFF), CircleShape),
            )
        }
    }
}

@Composable
private fun Dock(apps: List<AppEntry>, onOpen: (AppEntry) -> Unit, onInfo: (AppEntry) -> Unit) {
    Row(
        Modifier
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .fillMaxWidth()
            .height(86.dp)
            .clip(RoundedCornerShape(34.dp))
            .background(Color(0x40FFFFFF)),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        apps.take(4).forEach { AppIcon(it, onOpen, onInfo, showLabel = false) }
    }
}

@Composable
private fun TodayPage(onOpenAod: () -> Unit) {
    val ctx = LocalContext.current
    val now by rememberNow()
    val battery by rememberBattery()

    val is24 = remember(now) { android.text.format.DateFormat.is24HourFormat(ctx) }
    val time = remember(now, is24) {
        SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault()).format(Date(now))
    }
    val date = remember(now) {
        SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(now))
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Column(Modifier.padding(start = 6.dp, bottom = 6.dp)) {
            Txt(date, 17.sp, Color(0xE6FFFFFF), FontWeight.Medium, shadow = true)
            Txt(time, 84.sp, Color.White, FontWeight.Thin, shadow = true)
        }

        GlassCard {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Txt("Battery", 14.sp, Color(0xB3FFFFFF), FontWeight.SemiBold)
                    Txt(
                        "${battery.pct}%" + if (battery.charging) "  charging" else "",
                        14.sp,
                        Color.White,
                        FontWeight.SemiBold,
                    )
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape)
                        .background(Color(0x33FFFFFF)),
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth((battery.pct / 100f).coerceIn(0.02f, 1f))
                            .fillMaxHeight()
                            .background(
                                if (battery.pct <= 20 && !battery.charging) Color(0xFFFF453A) else Color(0xFF30D158),
                                CircleShape,
                            ),
                    )
                }
            }
        }

        GlassCard(Modifier.pressClick { onOpenAod() }) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Txt("Clock screen", 17.sp, Color.White, FontWeight.SemiBold)
                Txt(
                    "Always-on style black clock. Tap to start, double-tap to exit.",
                    13.sp,
                    Color(0xB3FFFFFF),
                    maxLines = 2,
                )
            }
        }

        GlassCard(
            Modifier.pressClick {
                try {
                    ctx.startActivity(
                        Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                } catch (_: Exception) { }
            },
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Txt("Notification icons", 17.sp, Color.White, FontWeight.SemiBold)
                Txt(
                    "Allow notification access to show app icons on the clock screen.",
                    13.sp,
                    Color(0xB3FFFFFF),
                    maxLines = 2,
                )
            }
        }
    }
}
