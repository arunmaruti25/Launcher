package com.haze.launcher.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings

data class AppEntry(val label: String, val pkg: String, val cls: String) {
    val key: String get() = "$pkg/$cls"
}

/** Reads the installed app list. Holds no state, so it costs no memory between calls. */
object AppRepo {

    @Suppress("DEPRECATION")
    fun load(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val probe = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(probe, 0)
            .asSequence()
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name) }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    /** Phone, Messages, Browser, Camera: whatever the phone uses by default. */
    fun dock(ctx: Context, apps: List<AppEntry>): List<AppEntry> {
        val pm = ctx.packageManager
        val probes = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com")),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
        )
        val result = ArrayList<AppEntry>(4)
        for (p in probes) {
            val pkg = pm.resolveActivity(p, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName ?: continue
            if (result.any { it.pkg == pkg }) continue
            apps.firstOrNull { it.pkg == pkg }?.let { result.add(it) }
        }
        // If a default was missing, fill the gap so the dock always has four apps
        for (a in apps) {
            if (result.size >= 4) break
            if (result.none { it.key == a.key }) result.add(a)
        }
        return result
    }

    fun launch(ctx: Context, app: AppEntry) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(app.pkg, app.cls)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { ctx.startActivity(i) } catch (_: Exception) { }
    }

    fun showInfo(ctx: Context, app: AppEntry) {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) { }
    }
}
