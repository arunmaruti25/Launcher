package com.haze.launcher.aod

import android.graphics.drawable.Icon
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Hand-off between the notification listener and the clock screen (a short list of small icons). */
object NotifHub {
    @Volatile
    var icons: List<Icon> = emptyList()
        private set

    @Volatile
    var listener: (() -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())

    fun update(list: List<Icon>) {
        icons = list
        main.post { listener?.invoke() }
    }
}

/** Only runs if the user grants Notification access. Keeps one small icon per app. */
class NotifService : NotificationListenerService() {

    override fun onListenerConnected() = refresh()
    override fun onNotificationPosted(sbn: StatusBarNotification) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification) = refresh()
    override fun onListenerDisconnected() = NotifHub.update(emptyList())

    private fun refresh() {
        val active: Array<StatusBarNotification> = try {
            activeNotifications ?: emptyArray()
        } catch (_: Exception) {
            emptyArray()
        }
        val seen = HashSet<String>()
        val out = ArrayList<Icon>()
        for (n in active) {
            if (n.isOngoing) continue
            if (seen.add(n.packageName)) n.notification.smallIcon?.let { out.add(it) }
        }
        NotifHub.update(out)
    }
}
