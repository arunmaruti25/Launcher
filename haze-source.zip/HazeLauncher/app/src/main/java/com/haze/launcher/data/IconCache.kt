package com.haze.launcher.data

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

/**
 * Icons are drawn at the exact size they are shown (no oversized bitmaps) and kept in a
 * hard-capped 6 MB cache. The cache is emptied whenever the launcher goes to the background.
 */
object IconCache {

    private const val MAX_BYTES = 6 * 1024 * 1024

    private val cache = object : LruCache<String, ImageBitmap>(MAX_BYTES) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
    }

    fun get(appKey: String, px: Int): ImageBitmap? = cache.get("$appKey@$px")

    fun load(ctx: Context, app: AppEntry, px: Int): ImageBitmap {
        val k = "${app.key}@$px"
        cache.get(k)?.let { return it }

        val pm = ctx.packageManager
        val drawable: Drawable = try {
            pm.getActivityIcon(ComponentName(app.pkg, app.cls))
        } catch (_: Exception) {
            pm.defaultActivityIcon
        }

        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        if (Build.VERSION.SDK_INT >= 26 && drawable is AdaptiveIconDrawable) {
            // Adaptive layers are 108dp with a 72dp visible window: draw them full-bleed and let
            // the centre 72/108 fill the bitmap. The UI then clips it to an iOS-style squircle.
            val pad = (px * 0.25f).toInt()
            drawable.background?.apply { setBounds(-pad, -pad, px + pad, px + pad); draw(canvas) }
            drawable.foreground?.apply { setBounds(-pad, -pad, px + pad, px + pad); draw(canvas) }
        } else {
            drawable.setBounds(0, 0, px, px)
            drawable.draw(canvas)
        }

        val img = bmp.asImageBitmap()
        cache.put(k, img)
        return img
    }

    fun clear() = cache.evictAll()
}
