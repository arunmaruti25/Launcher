package com.haze.launcher.control

import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import com.haze.launcher.aod.AodActivity
import kotlin.math.roundToInt

/**
 * Everything the control center can do without root. Each call goes straight to a system
 * service; nothing is cached or polled, so it costs no memory while the panel is closed.
 */
class SystemControls(private val ctx: Context) {

    private val audio = ctx.getSystemService(AudioManager::class.java)
    private val notifications = ctx.getSystemService(NotificationManager::class.java)

    private var lastBrightness = -1
    private var lastPrompt = 0L

    private fun start(i: Intent) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
    }

    /** Asks (at most once every 4 s) for the one-time "Modify system settings" permission. */
    private fun ensureWriteSettings(): Boolean {
        if (Settings.System.canWrite(ctx)) return true
        val t = System.currentTimeMillis()
        if (t - lastPrompt > 4000) {
            lastPrompt = t
            start(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
        }
        return false
    }

    // ---- sliders ----------------------------------------------------------------------------

    fun brightness(): Float = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
    } catch (_: Exception) { 0.5f }

    fun setBrightness(v: Float) {
        if (!ensureWriteSettings()) return
        val n = (v * 255f).roundToInt().coerceIn(1, 255)
        if (n == lastBrightness) return
        val cr = ctx.contentResolver
        if (lastBrightness == -1) {
            Settings.System.putInt(
                cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL,
            )
        }
        lastBrightness = n
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, n)
    }

    fun volume(): Float {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
    }

    fun setVolume(v: Float) {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        try {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (v * max).roundToInt().coerceIn(0, max), 0)
        } catch (_: SecurityException) { }
    }

    // ---- toggles ----------------------------------------------------------------------------

    fun autoRotate(): Boolean =
        Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 1

    /** Returns the new auto-rotate state, or null if the permission screen was opened instead. */
    fun toggleRotate(): Boolean? {
        if (!ensureWriteSettings()) return null
        val next = !autoRotate()
        Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (next) 1 else 0)
        return next
    }

    fun dndOn(): Boolean {
        val f = notifications.currentInterruptionFilter
        return f == NotificationManager.INTERRUPTION_FILTER_PRIORITY ||
            f == NotificationManager.INTERRUPTION_FILTER_NONE ||
            f == NotificationManager.INTERRUPTION_FILTER_ALARMS
    }

    fun toggleDnd(): Boolean {
        if (!notifications.isNotificationPolicyAccessGranted) {
            start(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return dndOn()
        }
        val on = !dndOn()
        notifications.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL,
        )
        return on
    }

    // ---- connectivity (Android only lets apps open these screens, not flip them) ------------

    fun wifiOn(): Boolean = try {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    } catch (_: Exception) { false }

    fun bluetoothOn(): Boolean = try {
        ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
    } catch (_: Exception) { false }

    fun airplaneOn(): Boolean =
        Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1

    fun openInternet() = start(
        Intent(
            if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
            else Settings.ACTION_WIFI_SETTINGS,
        ),
    )

    fun openBluetooth() = start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    fun openAirplane() = start(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
    fun openMobileData() = start(Intent(Settings.ACTION_DATA_ROAMING_SETTINGS))

    // ---- media + shortcuts ------------------------------------------------------------------

    fun musicActive(): Boolean = audio.isMusicActive

    /** Sends a media key to whatever player is active (Spotify, YouTube Music, ...). */
    fun media(keyCode: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }

    fun openClockScreen() = start(Intent(ctx, AodActivity::class.java))
    fun camera() = start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
    fun clockApp() = start(Intent(AlarmClock.ACTION_SHOW_ALARMS))
    fun calculator() = start(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
    fun settings() = start(Intent(Settings.ACTION_SETTINGS))
}

class Torch(val on: State<Boolean>, val toggle: () -> Unit)

/** Flashlight: needs no permission, and the callback keeps the tile in sync with the system. */
@Composable
fun rememberTorch(ctx: Context): Torch {
    val cm = remember { ctx.getSystemService(CameraManager::class.java) }
    val id = remember {
        runCatching {
            cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        }.getOrNull()
    }
    val on = remember { mutableStateOf(false) }
    DisposableEffect(cm) {
        val cb = object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                if (cameraId == id) on.value = enabled
            }
        }
        cm.registerTorchCallback(cb, Handler(Looper.getMainLooper()))
        onDispose { cm.unregisterTorchCallback(cb) }
    }
    return remember {
        Torch(on) {
            id?.let { runCatching { cm.setTorchMode(it, !on.value) } }
        }
    }
}
