# Haze Launcher

iOS-style home screen, control center and always-on clock for Android. Kotlin + Jetpack Compose, no Material library, no image loader, no third-party dependencies.

## Build the APK without Android Studio (GitHub)
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab. The "Build APK" workflow starts on its own (or press **Run workflow**).
3. When it finishes (about 5 minutes), open the run and download **haze-launcher-apk** at the bottom.
4. Unzip it, copy the `.apk` to your phone and install it (allow "install unknown apps" when asked).

## Build the APK with Android Studio
1. Open the `HazeLauncher` folder in Android Studio (Ladybug or newer). Let Gradle sync.
2. Plug in your phone (USB debugging on) and press Run, or build an installable file:
   `Build > Build Bundle(s) / APK(s) > Build APK(s)` (use the **release** variant for the smallest and smoothest build).
3. The APK is in `app/build/outputs/apk/`.

## First-run setup on the phone
- **Home app:** Settings > Apps > Default apps > Home app > Haze.
- **Brightness / rotation tiles:** the first tap opens "Modify system settings". Allow it for Haze.
- **Do Not Disturb tile:** first tap opens notification-policy access. Allow it for Haze.
- **Notification icons on the clock screen:** Settings > Notifications > Notification access > Haze (or tap the card on the Today page).
- **Clock as screen saver (auto-starts while charging):** Settings > Display > Screen saver > Haze Clock.
- **Clock quick tile:** edit your system Quick Settings panel and add "Clock screen".

## Using it
- Swipe right from the first app page for the Today page (time, battery, clock screen shortcut).
- Drag down from the very top edge for the control center. Drag it up or tap outside to close.
- Long-press an app icon for its App info page.
- Clock screen: double-tap to exit. It drifts a little every minute to avoid AMOLED burn-in.

## Why it is light on RAM
- No wallpaper bitmap: the system draws the wallpaper behind the launcher.
- Only the visible app page is composed. Icons are decoded off-thread at exact size into a 6 MB capped cache that is cleared when another app is in front.
- The control center is not in memory while closed. Its slide and fade run on the GPU layer without recomposing.
- Time comes from the system's once-a-minute tick, so there are no timers or polling loops.
- The clock screen uses plain Views and `TextClock`, with no Compose runtime of its own.
- Release builds are minified and resource-shrunk.

## Limits (Android rules, no root)
- Wi-Fi, Bluetooth, mobile data and airplane mode buttons open the system panel or settings page. Apps are not allowed to flip them directly.
- This is a screen-on clock, not the hardware AOD. On AMOLED the black pixels stay off, so drain is small. On LCD the backlight stays lit, so the clock screen closes itself after 10 minutes on battery (it stays on while charging). Best use on LCD: bedside/desk clock while charging, via the screen saver.
- The real system notification shade and Quick Settings still exist. This control center is a separate panel inside the launcher.
